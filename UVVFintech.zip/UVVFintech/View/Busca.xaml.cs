﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace UVVFintech.View
{
    /// <summary>
    /// Lógica interna para Busca.xaml
    /// </summary>
    public partial class Busca : Window
    {
        public Busca()
        {
            InitializeComponent();
        }

        private void buscaConta1_Click(object sender, RoutedEventArgs e)
        {
            buscarConta busca = new buscarConta();
            busca.Show();

        }

        private void buscaCliente1_Click(object sender, RoutedEventArgs e)
        {
            BuscarCliente buscaCliente = new BuscarCliente();
            buscaCliente.Show();
        }

        private void visuAllContas_Click(object sender, RoutedEventArgs e)
        {
            TodasContas todasContas = new TodasContas();    
            todasContas.Show();
        }

        private void visuAllCli_Click(object sender, RoutedEventArgs e)
        {
            TodosClientes todosClientes = new TodosClientes();  
            todosClientes.Show();
        }
    }
}
