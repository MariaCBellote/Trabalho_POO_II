﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UVVFintech.Model
{
    public class ContaPoupanca : Conta
    {
        public decimal TaxaRendimento { get; set; }
        public ContaPoupanca(string NumeroConta, Cliente titular, decimal Saldo) : base(NumeroConta, titular, Saldo)
        {
        }
        public override void Sacar(decimal valor)
        {

        }
    }
}
