﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UVVFintech.Model
{
    public abstract class Conta
    {
        public string NumeroConta { get; set; }
        public Cliente Titular { get; set; }

        public decimal Saldo { get; set; }

        public Conta(string numeroConta, Cliente titular, decimal Saldo)
        {
            NumeroConta = numeroConta;
            Titular = titular;
            this.Saldo = Saldo;

        }

        public virtual void Depositar(decimal valor)
        {
            Saldo += valor;
        }

        public abstract void Sacar(decimal valor);
    }
}
